import { Component } from '@angular/core';

@Component({
  selector: 'app-patientdashboard',
  templateUrl: './patientdashboard.component.html',
  styleUrl: './patientdashboard.component.css'
})
export class PatientdashboardComponent {

}
