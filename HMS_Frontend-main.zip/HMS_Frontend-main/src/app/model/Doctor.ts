export class Doctor{
    doctorId:number=0;
    doctorName:string="";
    gender:string="";
    speciality:string="";
    experience:number=0;
    qualification:string="";
    designation:string="";
    userName:string="";
    password:string="";
}