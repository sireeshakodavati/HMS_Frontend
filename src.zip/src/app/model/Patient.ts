export class Patient{
    patientId: number=0;
    userName: string="";
    password: string="";
    patientName: string="";
    dateOfBirth: string="";
    gender: string="";
    mobileNumber: number=0;
    disease: string="";
    natureOfVisit: string="";
    preferredDate: string="";
    preferredTime: string=""
}


