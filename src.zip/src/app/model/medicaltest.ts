export class MedicalTest{
    testId:number=0;
    testName:string="";
}