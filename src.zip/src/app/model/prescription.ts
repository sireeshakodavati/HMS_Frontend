export class Prescription{
    prescriptionId:number=0;
    medicineName:string="";
    price:number=0;
}