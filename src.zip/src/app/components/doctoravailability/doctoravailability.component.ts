import { Component } from '@angular/core';

@Component({
  selector: 'app-doctoravailability',
  templateUrl: './doctoravailability.component.html',
  styleUrl: './doctoravailability.component.css'
})
export class DoctoravailabilityComponent {

}
